# # Button '预订单(新建状态)'s Event :Command
# def Button_3_onCommand(uiName, widgetName):
#     store = Fun.GetCurrentValue(uiName, "门店下拉框")
#     store = store.split("/")
#
#     # 获取token
#     token = Fun.GetUserData('Project1', 'Form_1', 'token')
#     # 显示env环境
#     env = Fun.GetUserData('Project1', 'Form_1', 'value')
#     Fun.SetText(uiName, "env显示", env)
#
#     #
#     host = rf'https://dms{env}.yadea.com.cn'
#     api = r'/yd-sale/salReservat/saveSalReservat'
#     header = {'Authorization': token}
#     url = host + api
#     json = dict(docTime="2024-01-23", planDeliveryTime="2024-01-23", purFlag="1", contactName="史广杰",
#                 contactTel="18733980115", detailAddr="河北邢台巨鹿县泰泽西路", remark="快速接口", qty=1, amt=0,
#                 custId="423492058847906340", custCode="KH00000169", custName="test-接口", businessManager="经理2",
#                 businessId="258356", custStoreId="42804", custStoreCode="D03190601", custStoreName="秦泽西路雅迪专卖店",
#                 docStatus="", reservatDList=[{"itemCode": "10000-2003-0000",
#                                               "itemName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右",
#                                               "itemType": "PART", "itemTypeName": "配件", "itemType2": "PART",
#                                               "itemType2Name": "配件", "itemType5": "", "brand": "雅迪", "uom": "EA",
#                                               "uomName": "个", "es1": "配件", "remark": "", "purPrice": 0, "echrModel": "",
#                                               "lxfl": "", "tailBoxStatus": "", "amt": 0, "itemCodeOld": "L1020002326",
#                                               "discAmt": 0, "price": 0, "qty": 1, "itemId": "280661",
#                                               "printName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右"},
#                                              ], isSubmit="1", imgUrl="", createStoreId=store[2],
#                 createStoreCode=store[0], createStoreName=store[1])
#     res = request_api('post', url=url, headers=header, json=json)
#     res_msg = jsonpath(res, '$..msg')
#     res_success = res.get("response").get("success")
#     if res["status_code"] == 200 and res_msg[0] == "操作成功" and res_success == True:
#         Fun.MessageBox('推送成功')
#     else:
#         Fun.MessageBox('推送失败', res_msg)
#
#
# # Button '预订单(开单提交)'s Event :Command
# def Button_4_onCommand(uiName, widgetName):
#     store = Fun.GetCurrentValue(uiName, "门店下拉框")
#     store = store.split("/")
#
#     # 获取token
#     token = Fun.GetUserData('Project1', 'Form_1', 'token')
#     # 显示env环境
#     env = Fun.GetUserData('Project1', 'Form_1', 'value')
#     Fun.SetText(uiName, "env显示", env)
#
#     #
#     host = rf'https://dms{env}.yadea.com.cn'
#     api = r'/yd-sale/salReservat/saveSalReservat'
#     header = {'Authorization': token}
#     url = host + api
#     json = dict(docTime="2024-01-23", planDeliveryTime="2024-01-23", purFlag="1", contactName="史广杰",
#                 contactTel="18733980115", detailAddr="河北邢台巨鹿县泰泽西路", remark="快速接口", qty=1, amt=0,
#                 custId="423492058847906340", custCode="KH00000169", custName="test-接口", businessManager="经理2",
#                 businessId="258356", custStoreId="42804", custStoreCode="D03190601", custStoreName="秦泽西路雅迪专卖店",
#                 docStatus="", reservatDList=[{"itemCode": "10000-2003-0000",
#                                               "itemName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右",
#                                               "itemType": "PART", "itemTypeName": "配件", "itemType2": "PART",
#                                               "itemType2Name": "配件", "itemType5": "", "brand": "雅迪", "uom": "EA",
#                                               "uomName": "个", "es1": "配件", "remark": "", "purPrice": 0, "echrModel": "",
#                                               "lxfl": "", "tailBoxStatus": "", "amt": 0, "itemCodeOld": "L1020002326",
#                                               "discAmt": 0, "price": 0, "qty": 1, "itemId": "280661",
#                                               "printName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右"},
#                                              ], isSubmit="2", imgUrl="", createStoreId=store[2],
#                 createStoreCode=store[0], createStoreName=store[1])
#     res = request_api('post', url=url, headers=header, json=json)
#     res_msg = jsonpath(res, '$..msg')
#     res_success = res.get("response").get("success")
#     if res["status_code"] == 200 and res_msg[0] == "操作成功" and res_success == True:
#         Fun.MessageBox('推送成功')
#     else:
#         print(json)
#         print(res)
#         Fun.MessageBox(text=f'推送失败，{res_msg}；{res}')





