#coding=utf-8
import sys
import os
from   os.path import abspath, dirname
sys.path.insert(0,abspath(dirname(__file__)))
import tkinter
from   tkinter import *
import Fun
ElementBGArray={}  
ElementBGArray_Resize={} 
ElementBGArray_IM={} 

import traceback
import threading
import time
from tkinter import font
from jsonpath import jsonpath
#import requests
from Project1_cmd import request_api
def Form_1_onLoad(uiName):
    
    # 获取token
    token = Fun.GetUserData('Project1','Form_1','token')
    # 显示env环境
    env = Fun.GetUserData('Project1','Form_1','value')
    Fun.SetText(uiName,"env显示",env)
    
    # 获取 tenantID
    if env == 'prod':
        env = ''
        
    host = rf'https://dms{env}.yadea.com.cn'
    api = r'/yd-system/sys/users/current'
    header = {'Authorization':token}
    url = host + api
    res = request_api('get',url=url,headers=header)
    # 获取账号+name,全局访问
    buCode = jsonpath(res,'$..username')
    firstName = jsonpath(res,'$..firstName')
    Fun.AddUserData(uiName,'Form_1',dataName='buCode',datatype='string',datavalue=buCode[0],isMapToText=0)
    Fun.AddUserData(uiName,'Form_1',dataName='firstName',datatype='string',datavalue=firstName[0],isMapToText=0)
    print(res)
    print(buCode,firstName)
    store_code = jsonpath(res,'$..storeCode')
    try:
        tenantId = jsonpath(res,'$..tenantId')[0]
        Fun.AddUserData(uiName,'Form_1',dataName='tenantId',datatype='string',datavalue=tenantId,isMapToText=0)
        
        # 门店列表
        store = jsonpath(res,'$..authorizeScopes')
        store = [store['objCode'] +'/'+ store['objName'] + '/' + str(store['objId']) for store in store[0] ]
        print(store)
        Fun.SetValueList(uiName,"门店下拉框",store)
        Fun.SetCurrentValue(uiName,"门店下拉框",store[0])
        
    except Exception as Ex:
        print(Ex)
        Fun.MessageBox(text='API：/yd-system/sys/users/current,登录账号门店信息获取失败',title='提示',type='error',parent=None)
    #Fun.LoadUIDialog(uiName,'Frame_2','dianShang_win')
    
    
    
    # 获取门店列表
    pass
    
#Button '访问云销通's Event :Command
def Button_1_onCommand(uiName,widgetName):
    import webbrowser
    env = Fun.GetUserData('Project1','Form_1','value')
    if env == 'prod':
        env = ''
    webbrowser.open(f'https://dms{env}.yadea.com.cn/login')
    
    
#Button '切换账号's Event :Command
def 切换账号_onCommand(uiName,widgetName):
    Fun.GoToUIDialog(uiName,"Project1")
    pass
    
    
def 门店下拉框_onSelect(event,uiName,widgetName):
    Fun.MessageBox(text='切换门店后，请重新进入菜单！否则切换失败！',title='提示',type='info',parent=None)
    
def LabelButton_1_onCommand(uiName,widgetName):
    store = Fun.GetCurrentValue(uiName, "门店下拉框")
    store = store.split("/")

    # 获取token
    token = Fun.GetUserData('Project1', 'Form_1', 'token')
    # 显示env环境
    env = Fun.GetUserData('Project1', 'Form_1', 'value')
    Fun.SetText(uiName, "env显示", env)

    #
    host = rf'https://dms{env}.yadea.com.cn'
    api = r'/yd-sale/salReservat/saveSalReservat'
    header = {'Authorization': token}
    url = host + api
    json = dict(docTime="2024-01-23", planDeliveryTime="2024-01-23", purFlag="1", contactName="史广杰",
                contactTel="18733980115", detailAddr="河北邢台巨鹿县泰泽西路", remark="快速接口", qty=1, amt=0,
                custId="423492058847906340", custCode="KH00000169", custName="test-接口", businessManager="经理2",
                businessId="258356", custStoreId="42804", custStoreCode="D03190601", custStoreName="秦泽西路雅迪专卖店",
                docStatus="", reservatDList=[{"itemCode": "10000-2003-0000",
                                              "itemName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右",
                                              "itemType": "PART", "itemTypeName": "配件", "itemType2": "PART",
                                              "itemType2Name": "配件", "itemType5": "", "brand": "雅迪", "uom": "EA",
                                              "uomName": "个", "es1": "配件", "remark": "", "purPrice": 0, "echrModel": "",
                                              "lxfl": "", "tailBoxStatus": "", "amt": 0, "itemCodeOld": "L1020002326",
                                              "discAmt": 0, "price": 0, "qty": 1, "itemId": "280661",
                                              "printName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右"},
                                             ], isSubmit="1", imgUrl="", createStoreId=store[2],
                createStoreCode=store[0], createStoreName=store[1])
    res = request_api('post', url=url, headers=header, json=json)
    res_msg = jsonpath(res, '$..msg')
    res_success = res.get("response").get("success")
    if res["status_code"] == 200 and res_msg[0] == "操作成功" and res_success == True:
        Fun.MessageBox('推送成功')
    else:
        Fun.MessageBox('推送失败', res_msg)



def LabelButton_2_onCommand(uiName,widgetName):
    store = Fun.GetCurrentValue(uiName, "门店下拉框")
    store = store.split("/")

    # 获取token
    token = Fun.GetUserData('Project1', 'Form_1', 'token')
    # 显示env环境
    env = Fun.GetUserData('Project1', 'Form_1', 'value')
    Fun.SetText(uiName, "env显示", env)

    #
    host = rf'https://dms{env}.yadea.com.cn'
    api = r'/yd-sale/salReservat/saveSalReservat'
    header = {'Authorization': token}
    url = host + api
    json = dict(docTime="2024-01-23", planDeliveryTime="2024-01-23", purFlag="1", contactName="史广杰",
                contactTel="18733980115", detailAddr="河北邢台巨鹿县泰泽西路", remark="快速接口", qty=1, amt=0,
                custId="423492058847906340", custCode="KH00000169", custName="test-接口", businessManager="经理2",
                businessId="258356", custStoreId="42804", custStoreCode="D03190601", custStoreName="秦泽西路雅迪专卖店",
                docStatus="", reservatDList=[{"itemCode": "10000-2003-0000",
                                              "itemName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右",
                                              "itemType": "PART", "itemTypeName": "配件", "itemType2": "PART",
                                              "itemType2Name": "配件", "itemType5": "", "brand": "雅迪", "uom": "EA",
                                              "uomName": "个", "es1": "配件", "remark": "", "purPrice": 0, "echrModel": "",
                                              "lxfl": "", "tailBoxStatus": "", "amt": 0, "itemCodeOld": "L1020002326",
                                              "discAmt": 0, "price": 0, "qty": 1, "itemId": "280661",
                                              "printName": "电机/轮毂/48V/520/101.85/0.4KW/206.8/16-35鼓TY1/亚黑/无/24/扁12/铁/斜/0.9m/AM/右"},
                                             ], isSubmit="2", imgUrl="", createStoreId=store[2],
                createStoreCode=store[0], createStoreName=store[1])
    res = request_api('post', url=url, headers=header, json=json)
    res_msg = jsonpath(res, '$..msg')
    res_success = res.get("response").get("success")
    if res["status_code"] == 200 and res_msg[0] == "操作成功" and res_success == True:
        Fun.MessageBox('推送成功')
    else:
        print(json)
        print(res)
        Fun.MessageBox(text=f'推送失败，{res_msg}；{res}')




def 导航栏_onItemSelect(uiName,widgetName,itemText,itemValue):
    Fun.LoadUIDialog(uiName,'Frame_2',itemValue)
    

def Menu_检查(uiName,itemName):
    Fun.MessageBox(text='当前版本：V1.0.0\n制作者：Test-周通',title='提示',type='info',parent=None)

def get_store(uiName):
    store = Fun.GetCurrentValue(uiName,"门店下拉框")
    return store
