#coding=utf-8
#import libs 
import sys
import main_cmd
import main_sty
import Fun
import EXUIControl
EXUIControl.G_ExeDir = Fun.G_ExeDir
EXUIControl.G_ResDir = Fun.G_ResDir
import os
import tkinter
from   tkinter import *
import tkinter.ttk
import tkinter.font
#Add your Varial Here: (Keep This Line of comments)
#Define UI Class
class  main:
    def __init__(self,root,isTKroot = True):
        uiName = Fun.GetUIName(root,self.__class__.__name__)
        self.uiName = uiName
        Fun.Register(uiName,'UIClass',self)
        self.root = root
        self.isTKroot = isTKroot
        self.firstRun = True
        Fun.G_UICommandDictionary[uiName]=main_cmd
        Fun.Register(uiName,'root',root)
        style = main_sty.SetupStyle()
        if isTKroot == True:
            root.title("云销通实用组件V1.0.0           作者：Test-周通")
            Fun.WindowDraggable(root,True,0,'#FFFFFF')
            root.wm_attributes("-transparentcolor","#00FFFF")
            if os.path.exists("Resources/title.ico"):
                root.iconbitmap("Resources/title.ico")
            Fun.CenterDlg(uiName,root,1188,767)
            root['background'] = '#F6F6F6'
        root.bind('<Configure>',self.Configure)
        Form_1= tkinter.Canvas(root,width = 10,height = 4)
        Form_1.pack(side=tkinter.TOP,fill=tkinter.BOTH,expand=True)
        Form_1.configure(width = 1188)
        Form_1.configure(height = 767)
        Form_1.configure(bg = "#F6F6F6")
        Form_1.configure(highlightthickness = 0)
        Fun.Register(uiName,'Form_1',Form_1)
        Fun.G_RootSize=[1188,767]
        #Create the elements of root 
        Frame_2 = tkinter.Frame(Form_1)
        Fun.Register(uiName,'Frame_2',Frame_2,'Frame_1')
        Fun.SetControlPlace(uiName,'Frame_2',-30,0,1224,57)#lock
        Frame_2.configure(bg = "#FF7816")
        Frame_2.configure(relief = "flat")
        Button_3 = tkinter.Button(Frame_2,text="访问云销通")
        Fun.Register(uiName,'Button_3',Button_3,'Button_1')
        Fun.SetControlPlace(uiName,'Button_3',1078,0,140,57)#lock
        Button_3.configure(bg = "#FFFFFF")
        Button_3.configure(command=lambda:main_cmd.Button_1_onCommand(uiName,"Button_1"))
        Button_3_Ft=tkinter.font.Font(family='Microsoft YaHei UI Light', size=10,weight='normal',slant='roman',underline=0,overstrike=0)
        Button_3.configure(font = Button_3_Ft)
        Button_11 = tkinter.Button(Frame_2,text="切换账号")
        Fun.Register(uiName,'Button_11',Button_11,'切换账号')
        Fun.SetControlPlace(uiName,'Button_11',29,0,140,57)#lock
        Button_11.configure(bg = "#FFFFFF")
        Button_11.configure(command=lambda:main_cmd.切换账号_onCommand(uiName,"切换账号"))
        Button_11_Ft=tkinter.font.Font(family='Microsoft YaHei UI Light', size=10,weight='normal',slant='roman',underline=0,overstrike=0)
        Button_11.configure(font = Button_11_Ft)
        Label_9 = tkinter.Label(Frame_2,text="")
        Fun.Register(uiName,'Label_9',Label_9,'env显示')
        Fun.SetControlPlace(uiName,'Label_9',1003,0,75,57)#lock
        Label_9.configure(bg = "#FF7816")
        Label_9.configure(fg = "#FFFFFF")
        Label_9.configure(relief = "flat")
        Label_9_Ft=tkinter.font.Font(family='Microsoft YaHei UI', size=15,weight='normal',slant='roman',underline=0,overstrike=0)
        Label_9.configure(font = Label_9_Ft)
        Label_14 = tkinter.Label(Frame_2,text="当前门店")
        Fun.Register(uiName,'Label_14',Label_14,'当前门店')
        Fun.SetControlPlace(uiName,'Label_14',393,0,119,57)#lock
        Label_14.configure(bg = "#FFFFFF")
        Label_14.configure(fg = "SystemButtonText")
        Label_14.configure(relief = "flat")
        Label_14_Ft=tkinter.font.Font(family='新宋体', size=12,weight='bold',slant='roman',underline=0,overstrike=0)
        Label_14.configure(font = Label_14_Ft)
        ComboBox_13_Variable = Fun.AddTKVariable(uiName,'ComboBox_13')
        ComboBox_13 = tkinter.ttk.Combobox(Frame_2,textvariable=ComboBox_13_Variable, state="readonly")
        ComboBox_13_Ft=tkinter.font.Font(family='Microsoft YaHei UI', size=12,weight='normal',slant='roman',underline=0,overstrike=0)
        ComboBox_13.configure(font = ComboBox_13_Ft)
        Fun.Register(uiName,'ComboBox_13',ComboBox_13,'门店下拉框')
        Fun.SetControlPlace(uiName,'ComboBox_13',512,0,300,57)#lock
        ComboBox_13.bind("<<ComboboxSelected>>",Fun.EventFunction_Adaptor(main_cmd.门店下拉框_onSelect,uiName=uiName,widgetName="门店下拉框"))
        Frame_17 = tkinter.Frame(Form_1)
        Fun.Register(uiName,'Frame_17',Frame_17,'Frame_2')
        Fun.SetControlPlace(uiName,'Frame_17',300,80,877,675)#lock
        Frame_17.configure(bg = "#FFFFFF")
        Frame_17.configure(relief = "flat")
        LabelButton_18= EXUIControl.LabelButton(Frame_17)
        Fun.Register(uiName,'LabelButton_18',LabelButton_18,'LabelButton_1')
        LabelButton_18.SetText("预订单(新建")
        LabelButton_18.SetBGColor("#F6F6F6")
        LabelButton_18.SetFGColor("#000000")
        LabelButton_18.SetBGColor_Hover("#AAAAAA")
        LabelButton_18.SetFGColor_Hover("#000000")
        LabelButton_18.SetBGColor_Click("#AAAAAA")
        LabelButton_18.SetFGColor_Click("#FF0000")
        Fun.SetControlPlace(uiName,'LabelButton_18',163,261,200,48)#lock
        LabelButton_18.SetCommandFunction(main_cmd.LabelButton_1_onCommand,self.uiName,"LabelButton_1")
        LabelButton_19= EXUIControl.LabelButton(Frame_17)
        Fun.Register(uiName,'LabelButton_19',LabelButton_19,'LabelButton_2')
        LabelButton_19.SetText("预订单(提交")
        LabelButton_19.SetBGColor("#F6F6F6")
        LabelButton_19.SetFGColor("#000000")
        LabelButton_19.SetBGColor_Hover("#AAAAAA")
        LabelButton_19.SetFGColor_Hover("#000000")
        LabelButton_19.SetBGColor_Click("#AAAAAA")
        LabelButton_19.SetFGColor_Click("#FF0000")
        Fun.SetControlPlace(uiName,'LabelButton_19',517,261,200,48)#lock
        LabelButton_19.SetCommandFunction(main_cmd.LabelButton_2_onCommand,self.uiName,"LabelButton_2")
        Label_23 = tkinter.Label(Frame_17,text="A0319019专用配件批发预订单，未专门开发！")
        Fun.Register(uiName,'Label_23',Label_23,'Label_4')
        Fun.SetControlPlace(uiName,'Label_23',222,172,433,48)
        Label_23.configure(bg = "#FFFFFF")
        Label_23.configure(fg = "SystemButtonText")
        Label_23.configure(relief = "flat")
        Label_23_Ft=tkinter.font.Font(family='Microsoft YaHei UI', size=15,weight='normal',slant='roman',underline=0,overstrike=0)
        Label_23.configure(font = Label_23_Ft)
        ListMenu_16= EXUIControl.ListMenu(Form_1)
        Fun.Register(uiName,'ListMenu_16',ListMenu_16,'导航栏')
        ListMenu_16.SetBGColor("#FFFFFF")
        ListMenu_16.SetTitleAnchor('left')
        ListMenu_16.SetTitleCompound('left')
        ListMenu_16.SetTitleSpacingX(10)
        ListMenu_16.SetTitleSpacingY(0)
        ListMenu_16.SetTitleBGColor("#FFFFFF")
        ListMenu_16.SetTitleFGColor("#000000")
        ListMenu_16_TitleFont=tkinter.font.Font(family='新宋体', size=12,weight='bold',slant='roman',underline=0,overstrike=0)
        ListMenu_16.SetTitleFont(ListMenu_16_TitleFont)
        ListMenu_16.SetTitleBGColor_Hover("#FFFFFF")
        ListMenu_16.SetTitleFGColor_Hover("#000000")
        ListMenu_16_TitleFont_Hover=tkinter.font.Font(family='新宋体', size=13,weight='bold',slant='roman',underline=0,overstrike=0)
        ListMenu_16.SetTitleFont_Hover(ListMenu_16_TitleFont_Hover)
        ListMenu_16.SetTitleBGColor_Click("#FFFFFF")
        ListMenu_16.SetTitleFGColor_Click("#000000")
        ListMenu_16_TitleFont_Click=tkinter.font.Font(family='新宋体', size=12,weight='bold',slant='roman',underline=0,overstrike=0)
        ListMenu_16.SetTitleFont_Click(ListMenu_16_TitleFont_Click)
        ListMenu_16.SetItemAnchor('left')
        ListMenu_16.SetItemCompound('left')
        ListMenu_16.SetItemSpacingX(0)
        ListMenu_16.SetItemSpacingY(0)
        ListMenu_16.SetItemBGColor("#FFFFFF")
        ListMenu_16.SetItemFGColor("#000000")
        ListMenu_16_ItemFont=tkinter.font.Font(family='新宋体', size=12,weight='normal',slant='roman',underline=0,overstrike=0)
        ListMenu_16.SetItemFont(ListMenu_16_ItemFont)
        ListMenu_16.SetItemBGColor_Hover("#FFFFFF")
        ListMenu_16.SetItemFGColor_Hover("#FF7816")
        ListMenu_16_ItemFont_Hover=tkinter.font.Font(family='新宋体', size=15,weight='bold',slant='roman',underline=0,overstrike=0)
        ListMenu_16.SetItemFont_Hover(ListMenu_16_ItemFont_Hover)
        ListMenu_16.SetItemBGColor_Click("#FFEDDF")
        ListMenu_16.SetItemFGColor_Click("#FF7816")
        ListMenu_16_ItemFont_Click=tkinter.font.Font(family='Arial', size=14,weight='bold',slant='roman',underline=0,overstrike=0)
        ListMenu_16.SetItemFont_Click(ListMenu_16_ItemFont_Click)
        Fun.SetControlPlace(uiName,'ListMenu_16',29,80,250,661)
        ListMenu_16.AddTitle("零售管理","二网补贴配置 icon.png")
        ListMenu_16.AddItem("电商发货订单","零售管理","","dianShang_win.py")
        ListMenu_16.AddItem("电商退货订单","零售管理","","RTorder.py")
        ListMenu_16.AddTitle("批发管理","救援工单 icon.png")
        ListMenu_16.AddItem("API接口自动化 开发ing","批发管理")
        ListMenu_16.AddItem("WebUI自动化 开发ing","批发管理")
        ListMenu_16.AddTitle("采购管理","工单结算明细 icon.png")
        ListMenu_16.AddItem("整车采购 开发ing","采购管理")
        ListMenu_16.AddItem("配件采购 开发ing","采购管理")
        ListMenu_16.AddTitle("系统设置","操作日志 icon.png")
        ListMenu_16.AddItem("门店推送","系统设置","","api_store.py")
        ListMenu_16.AddTitle("自动化配置","仓库设置 icon.png")
        ListMenu_16.AddItem("API接口模拟 开发ing","自动化配置")
        ListMenu_16.AddItem("下载Chrome驱动","自动化配置","","chrome.py")
        ListMenu_16.SetListMenuCallBackFunction(main_cmd.导航栏_onItemSelect,uiName,"导航栏")
        #Create the Menu of root 
        MainMenu=tkinter.Menu(root)
        root.config(menu = MainMenu)
        设置=tkinter.Menu(MainMenu,tearoff = 0)
        设置.add_command(label="检查",command=lambda:main_cmd.Menu_检查(uiName,"检查"))
        MainMenu.add_cascade(label="设置",menu=设置)
        #Inital all element's Data 
        Fun.InitElementData(uiName)
        #Call Form_1's OnLoad Function
        main_cmd.Form_1_onLoad(uiName)
        #Add Some Logic Code Here: (Keep This Line of comments)



        #Exit Application: (Keep This Line of comments)
        if self.isTKroot == True and Fun.GetElement(self.uiName,"root"):
            self.root.protocol('WM_DELETE_WINDOW', self.Exit)
            self.root.bind('<Escape>',self.Escape)  
    def GetRootSize(self):
        return Fun.G_RootSize[0],Fun.G_RootSize[1]
    def GetAllElement(self):
        return Fun.G_UIElementDictionary[self.uiName]
    def Escape(self,event):
        if Fun.AskBox('提示','确定退出程序？') == True:
            self.Exit()
    def Exit(self):
        if self.isTKroot == True:
            Fun.DestroyUI(self.uiName)

    def Configure(self,event):
        Form_1 = Fun.GetElement(self.uiName,'Form_1')
        if Form_1 == event.widget:
            Fun.ReDrawCanvasRecord(self.uiName)
        if self.root == event.widget:
            Fun.ResizeRoot(self.uiName,self.root,event)
            Fun.ResizeAllChart(self.uiName)
            uiName = self.uiName
            Fun.SetControlPlace(uiName,'Frame_1',-30,0,1224,57)#lock
            pass
        Fun.ActiveElement(self.uiName,event.widget)
#Create the root of Kinter 
if  __name__ == '__main__':
    root = tkinter.Tk()
    MyDlg = main(root)
    root.mainloop()
