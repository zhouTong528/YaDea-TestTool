#coding=utf-8
import sys
import os
from   os.path import abspath, dirname
sys.path.insert(0,abspath(dirname(__file__)))
import tkinter
from   tkinter import *
import Fun
ElementBGArray={}  
ElementBGArray_Resize={} 
ElementBGArray_IM={} 

from Project1_cmd import request_api
import json
import ast
import re
import threading
import numpy as np
import random
import string
from datetime import datetime
from Project1_cmd import request_api
from jsonpath import jsonpath
def Form_1_onLoad(uiName):
    # host
    env = Fun.GetText('main','env显示')
    if env == 'prod':
        env = ''
    host = rf'https://dms{env}.yadea.com.cn'
    Fun.SetText(uiName,"Entry_2",host)
    
    



def 发送_onCommand(uiName,widgetName):
    # host
    host = Fun.GetText(uiName,"Entry_2")
    # api
    api = Fun.GetText(uiName,"Entry_8")
    if api == '':
        Fun.MessageBox(text='请输入api地址！',title='提示',type='info',parent=None)
        return
    url = host + api
    # method
    method = Fun.GetCurrentValue(uiName,"ComboBox_1")
    print(method)
    # header
    header_win = Fun.GetText(uiName,"Entry_7")
    if header_win:
        header_win = ast.literal_eval(header_win)
        if not type(header_win) == dict:
            Fun.MessageBox(text="请求头格式错误！请重新填写字典格式！\n例如：{'account':'123465789' , 'pwd':'888888'}",title='提示',type='info',parent=None)
            return
        
        token = Fun.GetUserData('Project1','Form_1','token')
        token_header = {'Authorization': token}
        
        header = {**header_win, **token_header}
    else:
        token = Fun.GetUserData('Project1','Form_1','token')
        header = {'Authorization': token}
    # 请求体格式
    format = Fun.GetCurrentValue(uiName,'RadioButton_1')
    if format == 1:
        format = 'params'
    elif format == 2:
        format = 'json'
    elif format == 3:
        format = 'data'
    print(format)
    # 请求body
    body = Fun.GetText(uiName,"Text_1")
    body = body.replace("\n", "")
    #print(body,type(body))
    if body == "":
        body = None
    elif body:
        try:
            body = json.loads(body)
        except Exception as Ex:
            Fun.MessageBox(text='请求body格式错误！请重新填写json格式(双引号)！\n例如：{"account":"123465789" , "pwd":"888888"}',title='提示',type='info',parent=None)
            return
            
    def request():
        if method == 'GET':
            res = request_api(url=url,method=method,headers=header,params=body)
        
        elif method == 'POST':
            if format == "json":
                res = request_api(url=url,method=method,headers=header,json=body)
            elif format == "data":
                res = request_api(url=url,method=method,headers=header,data=body)
            else:
                Fun.MessageBox(text='POST请求方式，请选择Json/Data',title='提示',type='info',parent=None)
                return
            
        elif method == 'PUT':
                if format == "json":
                    res = request_api(url=url,method=method,headers=header,json=body)
                elif format == "data":
                    res = request_api(url=url,method=method,headers=header,data=body)
                else:
                    Fun.MessageBox(text='PUT请求方式，请选择Json/Data',title='提示',type='info',parent=None)
                    return
                
    
        elif method == 'DELETE':
                if format == "json":
                    res = request_api(url=url,method=method,headers=header,json=body)
                elif format == "data":
                    res = request_api(url=url,method=method,headers=header,data=body)
                else:
                    Fun.MessageBox(text='DELETE请求方式，请选择Json/Data',title='提示',type='info',parent=None)
                    return
                    
        Fun.AddUserData(uiName,'Form_1',dataName='res',datatype='dict',datavalue=res,isMapToText=0)
        
        if res == None:
            Fun.MessageBox(text='请求错误！请检查后重试！',title='错误',type='warning',parent=None)
        else:
            def open_win():
                topmost = 1
                toolwindow = 1
                grab_set = 1
                animation = ''
                InputDataArray = Fun.CallUIDialog("response",topmost,toolwindow,grab_set,animation)
        
            run_thread = threading.Thread(target=open_win, args=[])
            run_thread.setDaemon(True)
            run_thread.start()

        
    run_thread = threading.Thread(target=request, args=[])
    run_thread.setDaemon(True)
    run_thread.start()
    

    
    

    
    
    
    
    
    
    
    pass
def Entry_3_onKey(event,uiName,widgetName):
    pass


def Entry_4_onKey(event,uiName,widgetName):
    pass


def ComboBox_1_onSelect(event,uiName,widgetName):
    pass
#RadioButton 'Params's Event :Command
def RadioButton_1_onCommand(uiName,widgetName):
    pass



#RadioButton 'Data's Event :Command
def RadioButton_3_onCommand(uiName,widgetName):
    pass

















def Text_1_onKey(event,uiName,widgetName):
    pass

















































